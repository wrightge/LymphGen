options(stringsAsFactors = FALSE)
Warnset=NULL

#flags that should be set before running
CGH.class=0 
Test.set=c("BN2","EZB","MCD","N1","ST2","A53")
HasL265P=T
Has.Trunc=T




##   Inputs that are dependent on the test samples

Mutation.flat=read.table("Mutation flat.txt",header=T,sep="\t")
if(dim(Mutation.flat)[2]==3)
{   Mutation.flat=data.frame(Mutation.flat,Location=-1)
}  


Copy.flat=read.table("Copy flat.txt",header=T,sep="\t")

Copy.flat=data.frame(Copy.flat,Location=-1)
names(Mutation.flat)=names(Copy.flat)
Flatfile=rbind(Copy.flat,Mutation.flat)

mut.genelist=read.table("mut.genelist.txt",header=T,sep="\t")
Sample.annot=read.table("Sample.annot.txt",header=T,sep="\t")
mut.genelist=mut.genelist[,1]



subtyp=unique(Flatfile[,3])
subtyp=subtyp[!is.element(subtyp,c("AMP","GAIN","HETLOSS","HOMDEL","TRUNC","Synon","L265P","MUTATION"))]

if(length(subtyp)>0)
{ Warnset=c(Warnset,makewarn("Unknown mutation types included:",subtyp,6))  
}
mutset=is.element(Flatfile[,3],c("TRUNC","Synon","L265P","MUTATION"))
mutset=unique(Flatfile[mutset,2])
mutset=mutset[!is.element(mutset,mut.genelist)]
if(length(mutset)>0)
{ Warnset=c(Warnset,makewarn("Genes with mutations included in flat file not found in mut.genelist:",mutset,6))
}



cgset=is.element(Flatfile[,3],c("AMP","GAIN","HETLOSS","HOMDEL"))
if(CGH.class!=1)
{ CGH.genelist=read.table("CGH.genelist.txt",header=T,sep="\t")
  CGH.genelist=CGH.genelist[,1]
  if(file.exists("Arm.file.txt"))
  { Arm.file=read.table("Arm.file.txt",header=T,sep="\t")}
  else
  {Arm.file=NULL
  } 
  cgset=unique(Flatfile[cgset,2])
  cgset=cgset[!is.element(cgset,CGH.genelist)]
  if(length(mutset)>0)
  { Warnset=c(Warnset,makewarn("Genes with copy number changes included in flat file not found in CGH.genelist:",cgset,6))  
  }
}
if(CGH.class==1)
{ Arm.file=NULL
  if(sum(cgset>0))
  {  Warnset=c(Warnset,"Copy number changes found in flat file but not included in analysis")}

}  



#  Inputs that are static for from the training data
#Fullmat.2019=Fullmat.save
Fullmat.2019=read.table("Fullmat.2019.txt",header=T,sep="\t")
#Fullmat.2019=as.matrix(Fullmat.2019==1)

Index.Flat=read.table("Index.Flat.txt",header=T,sep="\t")
Study.samp=read.table("Study.sampR.txt",header=T,sep="\t")
originalpred=read.table("originalpred.txt",header=T,sep="\t")
Full.Uber.2019=read.table("Full.Uber.2019.txt",header=T,sep="\t")
Genclass.lab=Study.samp[,3]
Genclass.lab[Genclass.lab=="SDT"]="ST2"


#mut.genelist=CGH.genelist=unique(Full.Uber.2019[,3])   #unflag to use complete genome
# Run predictor
result=Predict9(Flatfile,Sample.annot,Index.Flat,Genclass.lab,CGH.class=CGH.class,Full.Uber.2019,Fullmat.2019,originalpred=originalpred,Has.CGH=Study.samp[,2]==1,Arm.file=Arm.file,CGH.genelist=CGH.genelist,mut.genelist=mut.genelist,CalcWilcox=F,Test.set=Test.set,Has.Trunc=Has.Trunc)


#output results
write.table(result$Prediction,"Result.txt",quote=F,sep="\t",row.names=F,na="")
write.table(result$Compare,"Compare.txt",quote=F,sep="\t",row.names=F,na="")

Warnset=c(Warnset,result$Warn.set)
if(length(Warnset)==0)
{  Warnset="None"
}  
write.table(Warnset,"warn.txt",quote=F,sep="\t",row.names=F,col.names=F)
mod9=result$model.9
out.table=data.frame(1:574,original=originalpred)
lst=c("BN2","EZB","MCD","N1","SDT","A53")
mod.lst=c("Full","NOCGH","NoBCL6Fus", "NoBCL6CGH" ,"NoBCL2Fus", "NoBCL2CGH", "NoFus", "NoFusCGH","A53")
for(i in result$modset)
{ mod=mod9[[i]]
  out=data.frame(mod[[1]],weight=mod[[2]])
  out[,1]=Test.set[out[,1]]
  if(i<9)
  { cur.table=data.frame(result$Fullout[,,i])
    names(cur.table)=paste(lst,mod.lst[i])
    out.table=data.frame(out.table,cur.table)
  }
}



